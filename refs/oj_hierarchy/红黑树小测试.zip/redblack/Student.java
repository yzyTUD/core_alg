/**   
 * @Title: Student.java
 * @Package com.ywf.google.redblack
 * @Description: TODO ���ԵĶ���
 * @author ywf
 * @date 2015-2-4 ����10:18:50
 * @version V1.0 
 */
package com.ywf.google.redblack;

/**
 * Title: Rule-Engine <br>
 * Description: <br>
 * Date: 2015-2-4 <br>
 * @author ywf
 */
public class Student implements Comparable<Student>{

	private String name;
	private int age;
	private String family;
	/**
	 * @param name
	 * @param age
	 * @param family
	 */
	public Student(String name, int age, String family) {
		super();
		this.name = name;
		this.age = age;
		this.family = family;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getFamily() {
		return family;
	}
	public void setFamily(String family) {
		this.family = family;
	}
	
	@Override
	public int compareTo(Student s) {
		if(this.age>s.age){
			return 1;
		}else if(this.age<s.age){
			return -1;
		}else{
			return 0;
		}
	}
	
}
