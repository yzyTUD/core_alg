/**   
 * @Title: RedBlackTree.java
 * @Package com.ywf.google.redblack
 * @Description: TODO �����
 * @author ywf
 * @date 2015-2-3 ����04:03:49
 * @version V1.0 
 */
package com.ywf.google.redblack;

/**
 * Title: Rule-Engine <br>
 * Description: <br>
 * Date: 2015-2-3 <br>
 * @author ywf
 */
public class RedBlackTree<T extends Comparable<T>> {
    private Node<T> root; 
    private int size; 
    public int getSize() {
		return size;
	}

	private Node<T> NIL = new Node<T>(null, null, null, null, Color.BLACK); 
 
    public static class Node<E>{
        E value;
        Node<E> parent;
        Node<E> left;
        Node<E> right;
        Color color;
        public Node(E value, Node<E> parent, Node<E> left, Node<E> right, Color color) {
            this.value = value;
            this.parent = parent;
            this.left = left;
            this.right = right;
            this.color = color;
        }
    }
     
    private static enum Color{
        RED,
        BLACK
    }
    
    public Node<T> getRoot(){
    	return root;
    }
    
    private Node<T> uncle(Node<T> n){
        Node<T> gp = grandParent(n);
        if (gp == null) return null;
        if (n.parent == gp.left){
            return gp.right;
        } else {
            return gp.left;
        }
    }
         
    private Node<T> grandParent(Node<T> n){
        if (n.parent == null) return null;
        return n.parent.parent;
    }
    
 
    private Node<T> getSuccessor(Node<T> n) {
    	Node<T> successorParent = null;
    	Node<T> successor = null;
    	if(n.left==null || n.left==NIL){
    		successor = n.right;
    		while(successor!=null && successor!=NIL){
        		successorParent = successor;
    			successor = successor.left;
    		}
    	}else{
    		successor = n.left;
    		while(successor!=null && successor!=NIL){
        		successorParent = successor;
    			successor = successor.right;
    		}
    	}
    	return successorParent;
    }
    
    public T min(Node<T> n) {
        Node<T> min = minN(n);
        return min == NIL ? null : min.value;
    }
     
    private Node<T> minN(Node<T> n) {
        Node<T> min = n;
        while (min.left != NIL) {
            min = min.left;
        }
        return min == NIL ? null : min;
    }
     
    public T max(Node<T> n) {
        Node<T> max = maxN(n);
        return max == NIL ? null : max.value;
    }
   
    public Node<T> maxN(Node<T> n) {
        Node<T> max = n;
        while (max.right != NIL) {
            max = max.right;
        }
        return max == NIL ? null : max;
    }
    
    private void leftRotate(Node<T> n){
        Node<T> rightChild = n.right;
        n.right = rightChild.left; 
        if(rightChild.left != NIL){
        	rightChild.left.parent = n;
        }
        rightChild.parent = n.parent;
        if (n.parent == null){
            root = rightChild;
        } else if (n.parent.left == n){
            n.parent.left = rightChild;
        } else {
            n.parent.right = rightChild;
        }
        rightChild.left = n;
        n.parent = rightChild;
    }

    private void rightRotate(Node<T> n){
        Node<T> leftChild = n.left;
        n.left = leftChild.right;
        if (leftChild.right != NIL){
        	leftChild.right.parent = n;
        }
        leftChild.parent = n.parent;
        if (n.parent == null){
            root = leftChild;
        } else if (n == n.parent.left){
            n.parent.left = leftChild;
        } else{
            n.parent.right = leftChild;
        }
        leftChild.right = n;
        n.parent = leftChild;
    }
   
    /**
     * ����Ԫ��
     */
    public boolean insert(T t){
        Node<T> n = new Node<T>(t, null, NIL, NIL, Color.RED); 
        Node<T> pointer = root;
        boolean inserted = false;
        while(!inserted){
            if (root == null){
                root = n;
                inserted = true;
            } else if (n.value.compareTo(pointer.value) > 0){
                if (pointer.right == NIL){
                    n.parent = pointer;
                    pointer.right = n;
                    inserted = true;
                } else{
                    pointer = pointer.right;
                }
            } else if (n.value.compareTo(pointer.value) < 0){
                if (pointer.left == NIL){
                    n.parent = pointer;
                    pointer.left = n;
                    inserted = true;
                } else{
                    pointer = pointer.left;
                }
            } else {
                return false;
            }
        }
        size++;
        insertFixup(n);
        return inserted;
    }
    
    private void insertFixup(Node<T> n) {
        if (n.parent == null){ 
            n.color = Color.BLACK;
            return;
        }
        if (n.parent.color == Color.BLACK){ 
            return;
        }
        Node<T> u = uncle(n);
        Node<T> g = grandParent(n);
        if (u != null && u.color == Color.RED){
            n.parent.color = Color.BLACK;
            u.color = Color.BLACK;
            g.color = Color.RED;
            insertFixup(g);
        } else {
            if (n == n.parent.right && n.parent == g.left){
                leftRotate(n.parent);
                n = n.left;
            } else if(n == n.parent.left && n.parent == g.right){
                rightRotate(n.parent);
                n = n.right;
            }
            n.parent.color = Color.BLACK;
            g.color = Color.RED;
            if (n == n.parent.left && n.parent == g.left){
                rightRotate(g);
            } else{
                leftRotate(g);
            }
        }
    }
   
    /**
     * ɾ��Ԫ��
     */
    public boolean remove(T t) {
        boolean removed = false;
        Node<T> n = find(t);
        Node<T> replace = null;
        Node<T> child = null;
        if (n != null && n.value!=null) {
            if (n.left == NIL || n.right == NIL ) {
                replace = n;
            } else {
                replace = getSuccessor(n);
            }
            child = replace.left != NIL ? replace.left : replace.right;
            child.parent = replace.parent;
            if (replace.parent == null) {
                root = child;
            } else if (replace == replace.parent.left) {
                replace.parent.left = child;
            } else {
                replace.parent.right = child;
            }
            if (replace != n) {
                n.value = replace.value;
            }
            if (replace.color == Color.BLACK) {
                removeFixup(child);
            }
            removed = true;
            size--;
        }
        return removed;
    }
     
    private void removeFixup(Node<T> n) {
        while (n != root && n.color == Color.BLACK && n!=null && n.value!=null) {
            if (n == n.parent.left) {
                Node<T> rightBrother = rightBrother(n);
                if (rightBrother.color == Color.RED) {
                    rightBrother.color = Color.BLACK;
                    n.parent.color = Color.RED;
                    leftRotate(n.parent);
                    rightBrother = n.parent.right;
                }
                if (rightBrother.left.color == Color.BLACK
                        && rightBrother.right.color == Color.BLACK) {
                    rightBrother.color = Color.RED;
                    n = n.parent;
                } else if (rightBrother.right.color == Color.BLACK) {
                    rightBrother.left.color = Color.BLACK;
                    rightBrother.color = Color.RED;
                    rightRotate(rightBrother);
                    rightBrother = n.parent.right;
                } else {
                    rightBrother.color = n.parent.color;
                    n.parent.color = Color.BLACK;
                    rightBrother.right.color = Color.BLACK;
                    leftRotate(n.parent);
                    n = root;
                }
            } else {
                Node<T> leftBrother = leftBrother(n);
                if (leftBrother.color == Color.RED) {
                    leftBrother.color = Color.BLACK;
                    n.parent.color = Color.RED;
                    rightRotate(n.parent);
                    leftBrother = n.parent.left;
                }
                if (leftBrother.left.color == Color.BLACK
                        && leftBrother.right.color == Color.BLACK) {
                    leftBrother.color = Color.RED;
                    n = n.parent;
                } else if (leftBrother.left.color == Color.BLACK) {
                    leftBrother.color = Color.RED;
                    leftBrother.right.color = Color.BLACK;
                    leftRotate(leftBrother);
                    leftBrother = n.parent.left;
                } else {
                    leftBrother.color = n.parent.color;
                    n.parent.color = Color.BLACK;
                    leftBrother.left.color = Color.BLACK;
                    rightRotate(n.parent);
                    n = root;
                }
            }
        }
        n.color = Color.BLACK;
    }
   
    private Node<T> rightBrother(Node<T> n) {
        return n == null ? null : (n.parent == null ? null : n.parent.right);
    }
   
    private Node<T> leftBrother(Node<T> n) {
        return n == null ? null : (n.parent == null ? null : n.parent.left);
    }
    
    /**
     * ����Ԫ��
     */
    public Node<T> find(T t){
		Node<T> current = root;
		while (t.compareTo(current.value)!=0){
			if (t.compareTo(current.value) < 0){
				current = current.left;
			}else{
				current = current.right;
			}	
			if (current == null){
				return null;
			}
		}
		return current;
	}

    /**
	 * @return String[] ��������Ԫ�ص��ַ������飬��һ��Ԫ���ǽڵ㵽���ڵ������������ڶ����Ǹýڵ����ڵĲ㼶��
	 */
    public String[] getSuper(Node<Student> n){
		if(n==null){
			return null;
		}else{
			String[] res = new String[2];
			String result ="";
			int i=1;
			boolean flag = true;
			while(n!=null && flag==true){
				if(n.parent==null){
					result =n.value.getAge() +"-->"+ result;
					break;
				}else{
					result =n.value.getAge() +"-->"+ result;
					i++;
					n = n.parent;
				}
			}
			res[0] = result;
			res[1] = i+"";
			return res;
		}
		
	}
    
    /**
	 * ��С���������
	 */
	public void inOrder(Node<Student> root){
		if(root!=null){
			inOrder(root.left);
			if(root.value!=null){
				String[] temp = getSuper(root);
				System.out.println("�ؼ��֣�"+root.value.getAge()+"��ɫ��"+ root.color+" �㼶����"+temp[1]+"��"+temp[0]);
			}
			inOrder(root.right);
		}
	}

}
