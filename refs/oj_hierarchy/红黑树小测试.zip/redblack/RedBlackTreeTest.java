/**   
 * @Title: RedBlackTreeTest.java
 * @Package com.ywf.google.redblack
 * @Description: TODO
 * @author ywf
 * @date 2015-2-4 ����10:17:51
 * @version V1.0 
 */
package com.ywf.google.redblack;

/**
 * Title: Rule-Engine <br>
 * Description: <br>
 * Date: 2015-2-4 <br>
 * @author ywf
 */
public class RedBlackTreeTest {
	
	/**
	 * @Title: main
	 * @Description: TODO
	 * @param args void 
	 * @author ywf 
	 * @date 2015-2-4 ����10:17:51
	 * @throws
	 **/
	public static void main(String[] args) {
		RedBlackTree<Student> ss = new RedBlackTree<Student>();
		Student s1 = new Student("lili",18,"�Ļ�·12��");
		Student s2 = new Student("lili",16,"�Ļ�·12��");
		Student s3 = new Student("lili",25,"�Ļ�·12��");
		Student s4 = new Student("lili",15,"�Ļ�·12��");
		Student s5 = new Student("lili",17,"�Ļ�·12��");
		Student s6 = new Student("lili",19,"�Ļ�·12��");
		Student s7 = new Student("lili",29,"�Ļ�·12��");
		Student[] sss = new Student[]{s1,s2,s3,s4,s5,s6,s7};
		
		for(int i=0;i<7;i++){
			ss.insert(sss[i]);
		}
		System.out.println("==============1");
		
		//---------����Ԫ��----
		Student s8 = new Student("lili",39,"�Ļ�·12��");
		Student s9 = new Student("lili",33,"�Ļ�·12��");
		Student s10 = new Student("lili",32,"�Ļ�·12��");
		Student s11 = new Student("lili",45,"�Ļ�·12��");
		Student s12 = new Student("lili",43,"�Ļ�·12��");
		Student s13 = new Student("lili",42,"�Ļ�·12��");
		Student s17 = new Student("lili",48,"�Ļ�·12��");
		Student s18 = new Student("lili",49,"�Ļ�·12��");
		Student s19 = new Student("lili",3,"�Ļ�·12��");
		Student s20 = new Student("lili",6,"�Ļ�·12��");
		Student s21 = new Student("lili",11,"�Ļ�·12��");
		Student s22 = new Student("lili",12,"�Ļ�·12��");
		Student s23 = new Student("lili",13,"�Ļ�·12��");
		Student s24 = new Student("lili",112,"�Ļ�·12��");
		Student s25 = new Student("lili",132,"�Ļ�·12��");
		Student s26 = new Student("lili",232,"�Ļ�·12��");
		Student s14 = new Student("lili",432,"�Ļ�·12��");
		Student s15 = new Student("lili",632,"�Ļ�·12��");
		Student s16 = new Student("lili",342,"�Ļ�·12��");	
		ss.insert(s8);
		ss.insert(s9);
		ss.insert(s10);
		ss.insert(s11);
		ss.insert(s12);
		ss.insert(s13);
		ss.insert(s17);
		ss.insert(s18);
		ss.insert(s19);
		ss.insert(s20);
		ss.insert(s21);
		ss.insert(s22);
		ss.insert(s23);
		ss.insert(s24);
		ss.insert(s25);
		ss.insert(s26);
		ss.insert(s14);
		ss.insert(s15);
		ss.insert(s16);
		ss.inOrder(ss.getRoot());
		
		System.out.println("==============2");
		System.out.println(ss.getSize());
		//ss.remove(s12);
//		ss.remove(s6);
		ss.remove(s13);
		
//		ss.remove(s22);
//		ss.remove(s23);
//		ss.remove(s3);
		System.out.println(ss.getSize());
//		ss.inOrder(ss.getRoot());
		//ss.remove(s15);
		ss.inOrder(ss.getRoot());
		System.out.println(ss.getSize());

	}

}
