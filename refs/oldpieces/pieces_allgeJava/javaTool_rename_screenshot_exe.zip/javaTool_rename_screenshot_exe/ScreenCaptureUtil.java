import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Calendar;
import javax.imageio.ImageIO;

public class ScreenCaptureUtil {
    private String fileName; 
    private String defaultName = "GuiCamera";
    static  String serialNum ;
    private String imageFormat; 
    private String defaultImageFormat = "png";
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();

    public ScreenCaptureUtil() {
        fileName = defaultName;
        imageFormat = defaultImageFormat;
    }

    public ScreenCaptureUtil(String s, String format) {
        fileName = s;
        imageFormat = format;
    }

    public String getUTCTimeStr() throws Exception {
		Calendar cal = Calendar.getInstance();
		return String.valueOf(cal.getTimeInMillis() );// 返回的就是UTC时间
	}

    /**************************************************************** 
     * snapShot the Gui once , you can use 
        https://www.epochconverter.com/ 
        to see the actual time local 
     ****************************************************************/
    public void snapShot() {
        try {
            BufferedImage screenshot = (new Robot()).createScreenCapture(new Rectangle(0, 0, (int) d.getWidth(), (int) d.getHeight()));
            //serialNum=System.currentTimeMillis();
            String name = fileName + getUTCTimeStr() + "." + imageFormat;
            File f = new File(name);
            System.out.print("Save File " + name);
            ImageIO.write(screenshot, imageFormat, f);
            System.out.print("..Finished!\n");
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static void main(String[] a) {
        ScreenCaptureUtil ScreenCapture = new ScreenCaptureUtil("C:\\Users\\yzy\\Desktop\\screenShotOnComputer\\", "jpg");
        ScreenCapture.snapShot();
    }
}