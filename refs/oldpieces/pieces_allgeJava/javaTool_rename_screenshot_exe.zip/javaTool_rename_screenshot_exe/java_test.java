import java.io.*;
class java_test{
    public static void renameInDir(File fl){
            //int num=1;
            String[] files=fl.list();
            File f=null;
            String filename="";
            for(int i=0;i<files.length;i++)
            {
                f=new File(fl,files[i]);// 
                filename=f.getName();
                //f.renameTo(new File(fl.getAbsolutePath()+"//"+filename.replace("-", "m")));    
                f.renameTo(new File(fl.getAbsolutePath()+"//"+(i+1)+".png"));                 
                //System.out.println(filename);
                // 
            }
    }
    public static void print(File f){
        if(f!=null){
            if(f.isDirectory()){
                System.out.println(f);
                File[] fileArray=f.listFiles();
                if(fileArray!=null){
                    for (int i = 0; i < fileArray.length; i++) {
                        //rec
                        print(fileArray[i]);
                    }
                }
            }
            else{
                System.out.println(f);
            }
        }
    }
    public static void main(String[] args) {
        //System.out.println(args[0]);
        //String fileName="C://Users//yzy//Desktop//test";
        File f=new File(args[0]);
        renameInDir(f);
        System.out.println("Finish!");
    }
}