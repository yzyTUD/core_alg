
setwd("C:\\Users\\yzy\\codes\\AS")
rm(list=ls())

#read the data 
cpudataf <- read.csv("data\\cpu.csv",header=TRUE,sep = ";")
memdataf <- read.csv("data\\mem.csv",header=TRUE,sep = ";")
netdataf <- read.csv("data\\net.csv",header=TRUE,sep = ";")

# change data frame to matrix 
cpuMatrix <- as.matrix(cpudataf)
memMatrix <- as.matrix(memdataf)
netMatrix <- as.matrix(netdataf)

# -------------------------------task4-------------------------------
# calculate with standerd methods
# it should be 36 * 36
cpucov <- cov(cpuMatrix)
cpucor <- cor(cpuMatrix)
memcov <- cov(memMatrix)
memcor <- cor(memMatrix)
netcov <- cov(netMatrix)
netcor <- cor(netMatrix)

#-------------------------------task5-------------------------------
# standerd method
scalecpu <- scale(cpuMatrix)
# calculate with our own method 
# we standerize each column at a time  
cpunumcol <- ncol(cpuMatrix)
cpuMatrixMM <-cpuMatrix
cputagc <-0
while (cputagc < cpunumcol) {
	cpuMatrixMean <- mean(cpuMatrixMM[,cputagc])
	cpuMatrixSd <- sd(cpuMatrixMM[,cputagc])
	cpunumrow <- nrow(cpuMatrix)
	cputagr <-0
	while(cputagr < cpunumrow)
	{
		cpuMatrixMM[cputagr,cputagc] <- (cpuMatrixMM[cputagr,cputagc]-cpuMatrixMean)/cpuMatrixSd
		cputagr=cputagr+1
	}
	cputagc = cputagc + 1
}

# the other two metricies
# standerd method 
scalemem <- scale(memMatrix)

# our method 
memnumcol <- ncol(memMatrix)
memMatrixMM <-memMatrix
memtagc <-0
while (memtagc < memnumcol) {
	memMatrixMean <- mean(memMatrixMM[,memtagc])
	memMatrixSd <- sd(memMatrixMM[,memtagc])
	memnumrow <- nrow(memMatrix)
	memtagr <-0
	while(memtagr < memnumrow)
	{
		memMatrixMM[memtagr,memtagc] <- (memMatrixMM[memtagr,memtagc]-memMatrixMean)/memMatrixSd
		memtagr=memtagr+1
	}
	memtagc = memtagc + 1
}

# standerd method
scalenet <- scale(netMatrix)

# our method 
netnumcol <- ncol(netMatrix)
netMatrixMM <-netMatrix
nettagc <-0
while (nettagc < netnumcol) {
	netMatrixMean <- mean(netMatrixMM[,nettagc])
	netMatrixSd <- sd(netMatrixMM[,nettagc])
	netnumrow <- nrow(netMatrix)
	nettagr <-0
	while(nettagr < netnumrow)
	{
		netMatrixMM[nettagr,nettagc] <- (netMatrixMM[nettagr,nettagc]-netMatrixMean)/netMatrixSd
		nettagr=nettagr+1
	}
	nettagc = nettagc + 1
}

# write to files 
write.csv(cpuMatrix,"MatrixCpu.csv")
write.csv(cpucov,"covcpu.csv")
write.csv(cpucor,"corcpu.csv")
write.csv(scalecpu,"scalecpu.csv")
write.csv(cpuMatrixMM,"scalecpuMM.csv")
# write to file 
write.csv(memMatrix,"MatrixMem.csv")
write.csv(memcov,"covmem.csv")
write.csv(memcor,"cormem.csv")
write.csv(scalemem,"scalemem.csv")
write.csv(memMatrixMM,"scalememMM.csv")
# write to file 
write.csv(netMatrix,"MatrixNet.csv")
write.csv(netcov,"covnet.csv")
write.csv(netcor,"cornet.csv")
write.csv(scalenet,"scalenet.csv")
write.csv(netMatrixMM,"scalenetMM.csv")

# -------------------------------task6 : gen a 3d array -------------------------------
Array <- array(c(cpuMatrix,memMatrix,netMatrix),dim = c(179,36,3))
write.csv(Array,"array.csv")

# -------------------------------task7 : plot density functions-------------------------------
# calculate the max 5 mean
cpuRankMean =array()
cpunumrowR <- nrow(cpuMatrix)
cpuRank <- cpuMatrix
cputag <- 0
while (cputag < cpunumrowR){
    is.array(cpuRank[cputag,])
    cpuRankMean[cputag] <- mean(cpuRank[cputag,])
    cputag=cputag+1
}

cpuRankResult <- rank(-cpuRankMean)
cpuRanktag <- 1
while(cpuRanktag<179){
    if(cpuRankResult[cpuRanktag]==1){
    cpuRankOut1 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==2){
    cpuRankOut2 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==3){
    cpuRankOut3 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==4){
    cpuRankOut4 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==5){
    cpuRankOut5 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    cpuRanktag=cpuRanktag+1
}

# plot 
plot(density(cpuMatrix[cpuRankOut1,]),main="density_cpu_max_mean")
lines(density(cpuMatrix[cpuRankOut2,]),col = 'red')
lines(density(cpuMatrix[cpuRankOut3,]),col = 'green')
lines(density(cpuMatrix[cpuRankOut4,]),col = 'yellow')
lines(density(cpuMatrix[cpuRankOut5,]),col = 'blue')
# save file 
write.csv(cpuRankResult,"RankResult_cpu_maxMean.csv")
write.csv(cpuRankMean,"RankResult_cpu_Mean.csv")


# calculate the max 5 sd
cpuRankMean =array()
cpunumrowR <- nrow(cpuMatrix)
cpuRank <- cpuMatrix
cputag <- 0
while (cputag < cpunumrowR){
    is.array(cpuRank[cputag,])
    cpuRankMean[cputag] <- sd(cpuRank[cputag,])
    cputag=cputag+1
}

cpuRankResult <- rank(-cpuRankMean)
cpuRanktag <- 1
while(cpuRanktag<179){
    if(cpuRankResult[cpuRanktag]==1){
    cpuRankOut1 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==2){
    cpuRankOut2 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==3){
    cpuRankOut3 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==4){
    cpuRankOut4 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==5){
    cpuRankOut5 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    cpuRanktag=cpuRanktag+1
}

# plot 
plot(density(cpuMatrix[cpuRankOut1,]),main="density_cpu_max_sd")
lines(density(cpuMatrix[cpuRankOut2,]),col = 'red')
lines(density(cpuMatrix[cpuRankOut3,]),col = 'green')
lines(density(cpuMatrix[cpuRankOut4,]),col = 'yellow')
lines(density(cpuMatrix[cpuRankOut5,]),col = 'blue')
#save file 
write.csv(cpuRankResult,"RankResult_cpu_maxSd.csv")
write.csv(cpuRankMean,"RankResult_cpu_sd.csv")

# -------------------------------task8 : correlation ? -------------------------------
# simple approch:
corelation_cpu_and_mem <- cor(c(cpuMatrix),c(memMatrix))
write.csv(corelation_cpu_and_mem,"corelation_cpu_and_mem_SIM.csv")
# better approch:
# we can choose different metrix to calculate e.g. MUC and MUM or something else