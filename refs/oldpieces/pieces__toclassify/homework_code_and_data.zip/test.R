rm(list=ls())

#read the data 
cpudataf <- read.csv("data\\cpu.csv",header=TRUE,sep = ";")
memdataf <- read.csv("data\\mem.csv",header=TRUE,sep = ";")
netdataf <- read.csv("data\\net.csv",header=TRUE,sep = ";")

# change data frame to matrix 
cpuMatrix <- as.matrix(cpudataf)
memMatrix <- as.matrix(memdataf)
netMatrix <- as.matrix(netdataf)

#
cpuRankMean =array()
cpunumrowR <- nrow(cpuMatrix)
cpuRank <- cpuMatrix
cputag <- 0
while (cputag < cpunumrowR){
    is.array(cpuRank[cputag,])
    cpuRankMean[cputag] <- mean(cpuRank[cputag,])
    cputag=cputag+1
}

cpuRankResult <- rank(-cpuRankMean)
cpuRanktag <- 1
while(cpuRanktag<179){
    if(cpuRankResult[cpuRanktag]==1){
    cpuRankOut1 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==2){
    cpuRankOut2 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==3){
    cpuRankOut3 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==4){
    cpuRankOut4 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    if(cpuRankResult[cpuRanktag]==5){
    cpuRankOut5 <- cpuRanktag
    # cpuRank[cpuRanktag,]
    }
    cpuRanktag=cpuRanktag+1
}

write.csv(cpuRankResult,"RankResult_cpu_maxMean.csv")
write.csv(cpuRankMean,"RankResult_cpu_Mean.csv")
