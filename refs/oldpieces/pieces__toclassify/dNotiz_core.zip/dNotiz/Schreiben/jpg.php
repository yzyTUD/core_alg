<html>
<head>

<meta charset="utf-8">
<script src="http://code.jquery.com/jquery-latest.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" /> 
</head>
<body>

</body>
<style type="text/css">
table
{
width: 100%
}
</style>
<?php
if(isset($_REQUEST['submit']))
{
  $filename=  $_FILES["imgfile"]["name"];
 
    if(file_exists($_FILES["imgfile"]["name"]))
    {
      echo "File name exists.";
    }
    else
    {
      move_uploaded_file($_FILES["imgfile"]["tmp_name"],"uploads/$filename");
      echo "Upload Successful .<br><br> Sie haben einen Hyperlink bekommen: <a href='uploads/$filename'>hier</a> <br>oder <b>uploads/$filename</b>";
	  //header("Location:http://www.zhirongtec.top/iik");
	  //exit;
    }
  
}
?>