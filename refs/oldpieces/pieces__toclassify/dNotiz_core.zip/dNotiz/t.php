<?php
	header('Access-Control-Allow-Origin:*');//注意！跨域要加这个头 上面那个没有
	header("content-type:text/html; charset=GBK");

    // $keyan = $_POST['keyan'];
    // $kecheng = $_POST['kecheng'];
    // $chuangye = $_POST['chuangye'];
    // $yanjiu = $_POST['yanjiu'];
    // $tingdu = $_POST['tingdu'];

    $ywc = $_POST['ywc'];
	$level = $_POST['level'];
	$filename = $_POST['filename'];
   
	// $json_string = json_encode($keyan);
	// file_put_contents('keyan.json', $json_string);
	// $json_string = json_encode($kecheng);
	// file_put_contents('kecheng.json', $json_string);
	// $json_string = json_encode($chuangye);
	// file_put_contents('chuangye.json', $json_string);
	// $json_string = json_encode($yanjiu);
	// file_put_contents('yanjiu.json', $json_string);
	// $json_string = json_encode($tingdu);
	// file_put_contents('tingdu.json', $json_string);

	$json_string = json_encode($ywc);
	file_put_contents('notiz/'.$filename.'', $json_string);
	$json_string = json_encode($level);
	file_put_contents('notiz_level/'.$filename.'', $json_string);

	echo "saved!";
?>