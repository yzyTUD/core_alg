<?php
//������ǰĿ¼�������ļ��ĺ�Ŀ¼��������װ��ʽ��ʾ
//1.��Ŀ¼�������ȡ�����Դ
//2.��ȡ�����Դ������ʾ��ǰ����Ŀ¼�µģ�Ŀ¼���ļ����ƣ�
header("Content-type:text/html;charset=GBK"); 
function getDirFile($path){

	if(!($file_handler=opendir($path)))
		return;
	
	$fileNTimes=array();
	//����-��ǰĿ¼��"�ļ�",�ų���php�ļ�
	while(false !== ($file=readdir($file_handler))){
		if($file=='.' || $file=='..' || $file=='index.php')
			continue;
		$fileNTimes[filemtime($path.'/'.$file)]=$file;
	}
	
	//����
	//krsort($fileNTimes);
	
	foreach ($fileNTimes as $mtime=>$file)
	{
		$file_path="$path/$file";							//·��
		$rel_path=str_replace(__DIR__."/", "", $file_path);	//���·��
		//��Ϊ-Ŀ¼
		if(is_dir($file_path)){
			//����"Ŀ¼����"����
			if(substr_count($file_path,"/")>1){
				$count=str_repeat("+",substr_count($file_path,"/"));
				echo $count.''.$file;
			}else{
				echo '+'.$file;
			}
			echo "<br/>";
			getDirFile($file_path);
		}
		//��Ϊ-�ļ�
		else{
			if(substr_count($file_path,"/")>1){
				$count=str_repeat("+++",substr_count($file_path,"/"));
			echo $count.'<tr><td><a href="/dNotiz/Schreiben/index.php?fp='.$rel_path.'">'.$file.'</a>'.getTime_html($mtime).'</td></tr>';
				
			}else{
				echo '<tr><td><a href="/dNotiz/Schreiben/index.php?fp='.$rel_path.'">'.$file.'</a>'.getTime_html($mtime).'</td></tr>';
			}
			echo "<br/>";
		}
	}
	
	echo "</table>";
}

function formatSizeUnits($bytes)
{
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' kB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }
        return '<a style="font-size:10px;color:grey">'.$bytes.'</a>';
}

function getTime_html($time){
	return '<a style="font-size:10px;color:grey"> '.date(' Y-m-d H:m:s ',$time).'</a>';
}

function getFile_html($rel_path,$file){
	return '<a href="'.$rel_path.'">'.$file.'</a>';
}


//-----------------------------------------

$path=__DIR__;
getDirFile($path);


?>
<html>
<head>

<meta charset="utf-8">
<script src="http://code.jquery.com/jquery-latest.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" /> 
</head>
<body background="../1.png">
</body>
<style type="text/css">
form
{
width: 100%
}
a{
	color: #000000;
}
</style> 