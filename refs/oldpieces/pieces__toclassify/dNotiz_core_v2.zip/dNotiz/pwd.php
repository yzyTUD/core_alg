<?php
	header('Access-Control-Allow-Origin:*');//注意！跨域要加这个头 上面那个没有
	header("content-type:text/html; charset=GBK");

    // $keyan = $_POST['keyan'];
    // $kecheng = $_POST['kecheng'];
    // $chuangye = $_POST['chuangye'];
    // $yanjiu = $_POST['yanjiu'];
    // $tingdu = $_POST['tingdu'];

    $mypwd = $_POST['mypwd'];
   
	if($mypwd=="86"){
		echo "t";
		session_start();
		$_SESSION["admin"] = true;
	}
	else if($mypwd=="out"){
		session_start();
		//  这种方法是将原来注册的某个变量销毁
		unset($_SESSION['admin']);
		//  这种方法是销毁整个 Session 文件
		session_destroy();
		echo "bravo";
	}
	else
		echo "f"
?>