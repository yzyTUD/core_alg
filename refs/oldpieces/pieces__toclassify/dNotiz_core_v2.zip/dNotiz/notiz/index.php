<?php
header("Content-type:text/html;charset=utf-8"); 
function getDirFile($path){

	if(!($file_handler=opendir($path)))
		return;
	$files=array();
	//push the files in to an array : files
	while(false !== ($file=readdir($file_handler))){
		if($file=='.' || $file=='..' || $file=='index.php')
			continue;
		array_push($files,$file);
	}
	
	//sort them 
	sort($files);
	
	foreach ($files as $file)
	{
		$file_path="$path/$file";							
		$rel_path=str_replace(__DIR__."/", "", $file_path);	// this is relative path
		
		if(is_dir($file_path)){
			$count=str_repeat("+",substr_count($rel_path,"/"));
			echo '<br>'.$count."+".$file;
			echo "<br/>";
			getDirFile($file_path);//recur
		}
		
		else{
			echo '<a href="/dNotiz/index.php?fp='.$rel_path.'">'
			.$file.'</a>'.'  '.formatSizeUnits(filesize($rel_path));
			echo "<br>";
		}
	}
}

function formatSizeUnits($bytes)
{
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' kB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }
        return '<a style="font-size:10px;color:grey">'.$bytes.'</a>';
}


function getFile_html($rel_path,$file){
	return '<a href="'.$rel_path.'">'.$file.'</a>';
}


//-----------------------------------------
//  ��ֹȫ�ֱ�����ɰ�ȫ����
$admin = false;
//  ��Ự���ⲽ�ز�����
session_start();
//  �ж��Ƿ��½
if (isset($_SESSION["admin"]) && $_SESSION["admin"] === true) {
    //echo "���Ѿ��ɹ���½";
} else {
    //  ��֤ʧ�ܣ��� $_SESSION["admin"] ��Ϊ false
    $_SESSION["admin"] = false;
	header('Location: '.$uri.'/dNotiz/login.html');
    die("����Ȩ����");
}

$path=__DIR__;
getDirFile($path);


?>
<html>
<head>

<meta charset="utf-8">
<script src="http://code.jquery.com/jquery-latest.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" /> 
</head>
<body background="../1.png">
</body>
<style type="text/css">
form
{
width: 100%
}
a{
	color: #000000;
}
</style> 